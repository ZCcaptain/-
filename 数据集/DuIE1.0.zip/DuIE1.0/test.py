import os
import json

def count_error(path):
    entities_count = 0
    error_count = 0
    error_sentence = 0
    
    with open(path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
        all_sentence = len(lines)
        for line in lines:
            line = line.strip()
            instance = json.loads(line)
            word = []
            for w in instance["postag"]:
                word.append(w['word'])
            entites = set()
            temp = error_count
            for spo in instance['spo_list']:
                entities_count += 2
                if spo['subject'] not in word:
                    error_count += 1
                    # print(spo['subject'], word)
                if  spo['object'] not in word:
                    error_count += 1
            if temp < error_count:
                error_sentence += 1
    print(entities_count, error_count)
    print(float(error_count) / float(entities_count))   
    print(error_sentence, all_sentence)  

if __name__ == "__main__":
    cwd = os.getcwd()
    count_error(os.path.join(cwd, 'dev_data.json'))
    count_error(os.path.join(cwd, 'train_data.json'))